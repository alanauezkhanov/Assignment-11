new Vue({
    el: "#app",
    data: {
        message: 'Hello, Vue!'
    }
})