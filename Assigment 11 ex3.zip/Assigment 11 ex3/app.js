new Vue({
    el: '#app',
    data: {
      username: '',
      defaultUsername: 'John',
    },
    computed: {
      greeting: function() {
        if (this.username !== '') {
          return 'Hello, ' + this.username + '!';
        } else {
          return 'Please enter your name.';
        }
      }
    },
    methods: {
      resetUsername: function() {
        this.username = this.defaultUsername;
      }
    }
  });