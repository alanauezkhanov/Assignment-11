new Vue({
    el: '#app',
    data: {
      username: '',
      email: '',
      password: '',
      errors: {}
    },
    computed: {
      hasErrors: function() {
        return Object.keys(this.errors).length > 0;
      }
    },
    methods: {
      submitForm: function() {
        this.errors = {};
  
        if (!this.username) {
          this.errors.username = 'Username is nessary.';
        }
  
        if (!this.email) {
          this.errors.email = 'Email is nessary.';
        } else if (!this.isValidEmail(this.email)) {
          this.errors.email = 'Email format is not valid.';
        }
  
        if (!this.password) {
          this.errors.password = 'Password is nessary.';
        } else if (this.password.length < 6) {
          this.errors.password = 'Password should have at least 6 characters.';
        }
  
        if (!this.hasErrors) {
          console.log('Form submitted successfully!');
        }
      },
      isValidEmail: function(email) {
        const emailRegex = /\S+@\S+\.\S+/;
        return emailRegex.test(email);
      }
    }
  });