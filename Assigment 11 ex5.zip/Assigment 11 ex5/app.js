// new Vue({
//     el: '#app',
//     data: {
//       tasks: [
//         { id: 1, title: 'Task 1', completed: false },
//         { id: 2, title: 'Task 2', completed: true },
//         { id: 3, title: 'Task 3', completed: false }
//       ],
//       newTask: ''
//     },
//     methods: {
//       toggleTaskCompletion(task) {
//         task.completed = !task.completed;
//       },
//       addTask() {
//         if (this.newTask !== '') {
//           const newTaskObj = {
//             id: this.tasks.length + 1,
//             title: this.newTask,
//             completed: false
//           };
//           this.tasks.push(newTaskObj);
//           this.newTask = '';
//         }
//       }
//     }
//   });

  new Vue({
    el: '#app',
    data: {
      tasks: [
        { title: 'Task 1', completed: false },
        { title: 'Task 2', completed: true },
        { title: 'Task 3', completed: false }
      ],
      newTask: ''
    },
    computed: {
      incompleteTasks() {
        return this.tasks.filter(task => !task.completed);
      },
      completedTasks() {
        return this.tasks.filter(task => task.completed);
      }
    },
    methods: {
      completeTask(task) {
        task.completed = true;
      },
      incompleteTask(task) {
        task.completed = false;
      },
      addTask() {
        if (this.newTask) {
          this.tasks.push({ title: this.newTask, completed: false });
          this.newTask = '';
        }
      }
    }
  });