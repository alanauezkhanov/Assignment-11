new Vue({
    el: "#app",
    data: {
        string: 'List of Fruits:',
        fruits: ['Apple', 'Banana', 'Orange','Grape','Watermelon','Strawberries'],
        newFruit: ''
      },
      methods: {
        addFruit() {
          if (this.newFruit !== '') {
            this.fruits.push(this.newFruit);
            this.newFruit = '';
          }
        },
        removeFruit(fruit) {
            const index = this.fruits.indexOf(fruit);
            if (index !== -1) {
              this.fruits.splice(index, 1);
            }
          }
    }
})